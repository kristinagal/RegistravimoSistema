﻿namespace RegistravimoSistema.DTOs
{
    public class UpdateFieldRequest
    {
        public string NewValue { get; set; } = string.Empty;
    }
}
